import pandas as pd
import os
dataframe = pd.read_csv('eclat.csv', header=None, delimiter=',')
param = pd.read_csv('param.csv', header=None, delimiter=',')
minsup = float(param[0])
mincom = int(param[1])
maxcom = int(param[2])

df = dataframe.drop(dataframe.columns[0], axis=1)
df.columns = df.columns-1

from pyECLAT import ECLAT
eclat_instance = ECLAT(data=df, verbose=True)

get_ECLAT_indexes, get_ECLAT_supports = eclat_instance.fit(min_support=minsup,
                                                           min_combination=mincom,
                                                           max_combination=maxcom,
                                                           separator=' , ',
                                                           verbose=True)

my_dict = get_ECLAT_supports
with open('support.csv', 'w') as f:
    for key in my_dict.keys():
        f.write("%s:%s\n"%(key,my_dict[key]))
        
file = 'lift.csv'
if(os.path.exists(file) and os.path.isfile(file)):
  os.remove(file)
for lift in get_ECLAT_supports:
    data=lift.split(' , ')
    if len(data)>1:
        sup=get_ECLAT_supports[lift]
        pembagi=1
        nomer=0
        combine = ""
        for item in data:
            if nomer>0:
                combine = combine+item
                if nomer < len(data)-1:
                    combine = combine+" , "        
            nomer=nomer+1
        pembagi=get_ECLAT_supports[data[0]]*get_ECLAT_supports[combine]
        result=sup/pembagi
        with open("lift.csv","a") as file:
            file.write(lift+":"+str(result)+"\n")