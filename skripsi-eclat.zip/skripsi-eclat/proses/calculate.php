<?php

if (isset($_POST['submit'])) 
	{
        // Open a file in write mode ('w')
			$fp = fopen('param.csv', 'w');
			$minsup = $_POST['minsup'];
            $mincom = $_POST['mincom'];
            $maxcom = $_POST['maxcom'];
            $param = [$minsup,$mincom,$maxcom];
            
			// Loop through file pointer and a line
			// foreach ($param as $fields) {
				fputcsv($fp, $param);
			// }
			
			fclose($fp);

            shell_exec("cmd /c C:/xampp/htdocs/skripsi-eclat/eclat.bat");

            $support = [];
            $handle = fopen('./support.csv', "r");
            while (($data = fgetcsv($handle, 1000, ":")) !== FALSE) 
            {
                array_push($support, $data);
            }

            fclose($handle);

            $lift = [];
            $handle = fopen('./lift.csv', "r");
            while (($data = fgetcsv($handle, 1000, ":")) !== FALSE) 
            {
                // $data = explode(":",$data[0]);
                array_push($lift, $data);
                // print_r($data[3]);
                // print_r($support);
                // exit(0);
            }

            fclose($handle);

            // echo "<pre>";
            // print_r($support);
            // echo "<pre>";
            // exit(0);

	}
	

?>