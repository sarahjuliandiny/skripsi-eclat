<?php

if (isset($_POST['submit'])) 
	{
		$date = explode("-",$_POST['daterange']);
		$newdata = [];

		$start = $date[0];
   		$end = $date[1];

		$handle = fopen($_FILES['filename']['tmp_name'], "r");
		$headers = fgetcsv($handle, 1000, ",");
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			$data = explode(";",$data[0]);
			if (strtotime($data[2]) >= strtotime($start) && strtotime($data[2]) <= strtotime($end)) {
				array_push($newdata, $data);
			}

		}

		$selectdata = $newdata;
		foreach($selectdata as $x=>$value){
				unset($selectdata[$x][0]);
				unset($selectdata[$x][2]);
				unset($selectdata[$x][3]);
				unset($selectdata[$x][4]);
				$selectdata[$x] = array_values($selectdata[$x]);
		}

		// echo "<pre>";
		// print_r($selectdata);
		// echo "</pre>";
		// exit(0);

		$duplicatedata = $selectdata;
		foreach($duplicatedata as $x=>$value){
					$duplicatedata[$x] = array_unique($duplicatedata[$x]);
					$duplicatedata[$x] = array_values($duplicatedata[$x]);
		}

		$customdata = $duplicatedata;
		foreach($customdata as $x=>$value){
				foreach($value as $y=>$v){
					if ($v == 'Custom Amount') {
						unset($customdata[$x][$y]);
						if($y==1){
							if(empty($value[$y+1])){
								unset($customdata[$x]);
							}
							
						}
						
					}
				}	
		}


			foreach($customdata as $x=>$value){
					foreach($value as $y=>$v){
						$lineCols = count($customdata[$x]);
						// if ($lineCols > $maxCols){
						// 	$maxCols = $lineCols;
						// }
						$maxCols = max(array_map('count', $customdata));
						for ($i = $lineCols; $i < $maxCols; $i++){
							array_push($customdata[$x], "");
						}
						
					}
					// echo "<pre>";
					// print_r($lineCols);
					// echo "</pre>";
					// exit(0);
			}

			
			// Open a file in write mode ('w')
			$fp = fopen('eclat.csv', 'w');
			
			// Loop through file pointer and a line
			foreach ($customdata as $fields) {
				fputcsv($fp, $fields);
			}
			
			fclose($fp);
			
			// $customdata = array_filter($newdata, function($v){
			// 	return $v != 'Custom Amount';
			// });

			// function rmv_val($var)
			// {
			// 	return(!($var == 'Custom Amount'));
			// }
			// $customdata = array_filter($newdata, "rmv_val");

			// function array_delete($del_val, $array) {
			// 	if(is_array($del_val)) {
			// 		 foreach ($del_val as $del_key => $del_value) {
			// 			foreach ($array as $key => $value){
			// 				if ($value == $del_value) {
			// 					unset($array[$key]);
			// 				}
			// 			}
			// 		}
			// 	} else {
			// 		foreach ($array as $key => $value){
			// 			if ($value == $del_val) {
			// 				unset($array[$key]);
			// 			}
			// 		}
			// 	}
			// 	return array_values($array);
			// }
			// // $customdata = array_delete(array('Custom Amount'), $newdata);

		// 	foreach($newdata as $d=>$value){
		// 			if(empty($d)){
		// 			  $duplicatedata=array($row['receipt_number'],$data);
		// 			}else{
					  
		// 			  if (!in_array($data, $jangkrik[$row["receipt_number"]])){
		// 				  array_push($jangkrik[$row["receipt_number"]],$data);
		// 			  }
		// 			}
		// 	}

		// foreach($newdata as $x=>$value){
		// 	if($x>4){
		// 		$duplicatedata = array_unique($newdata, SORT_REGULAR);
		// 	  }
		// 	}

fclose($handle);
	}
	

?>