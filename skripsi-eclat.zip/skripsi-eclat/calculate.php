<!--
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!doctype html>
<html lang="en">
<?php include('proses/calculate.php') ?>

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        Analisis ECLAT Pagikemalam Coffee and Eatery
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/css/datatables.css" rel="stylesheet" />
    <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="./assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-small">
                        <img src="assets/img/logo.png">
                    </div>
                    <!-- <p>CT</p> -->
                </a>
                <a href="" class="simple-text logo-normal">
                    Pagikemalam
                    <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="index.php">
                            <i class="nc-icon nc-shop"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="import.php">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Import Dataset</p>
                        </a>
                    </li>
                    <li class="active ">
                        <a href="calculate.php">
                            <i class="nc-icon nc-cart-simple"></i>
                            <p>Calculate ECLAT</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel" style="">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="javascript:;">Pagikemalam Coffee and Eatery</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>

                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <form action='' method='post'>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-4 pl-1">
                                <div class="form-group">
                                    <label for="minsup">Minimum Support</label>
                                    <input type="text" class="form-control" placeholder="Ex: 0.02" name="minsup" required>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for="mincom">Minimum Combination</label>
                                <input type="text" class="form-control" placeholder="Ex: 1" name="mincom" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="maxcom">Maximum Combination</label>
                                <input type="text" class="form-control" placeholder="Ex: 3" name="maxcom" required>
                            </div>
                        </div>
                    </div>
                    <div class="update ml-auto mr-auto">
                        <button type="submit" class="btn btn-primary btn-round" name="submit">Calculate</button>
                    </div>        
        </form>
        <br>
        <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> Support</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="support">
                                        <thead class=" text-primary">
                                            <th>
                                                Items
                                            </th>
                                            <th>
                                                Support
                                            </th>
                                        </thead>
                                        <tbody>
                                            <?php
                      if (isset($_POST['submit'])) 
                      {
                        foreach ($support as $s) { ?>
                                            <tr>
                                                <td>
                                                    <?= $s[0] ?>
                                                </td>
                                                <td>
                                                    <?= $s[1] ?>
                                                </td>
                                            </tr>
                                            <?php
                        }
                      }
                      ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> Lift Ratio</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="lift">
                                        <thead class=" text-primary">
                                            <th>
                                                Items
                                            </th>
                                            <th>
                                                Lift Ratio
                                            </th>
                                        </thead>
                                        <tbody>
                                            <?php
                      if (isset($_POST['submit'])) 
                      {
                        foreach ($lift as $l) { ?>
                                            <tr>
                                                <td>
                                                    <?= $l[0] ?>
                                                </td>
                                                <td>
                                                    <?= $l[1] ?>
                                                </td>
                                            </tr>
                                            <?php
                        }
                      }
                      ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                
            </div>
    </div>
    <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
                <div class="container-fluid">
                    <div class="row">
                        <nav class="footer-nav">

                        </nav>
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © 2020, made with <i class="fa fa-heart heart"></i> by Creative Tim
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
    </div>
    </div>
    <!--   Core JS Files   -->
    <script src="./assets/js/core/jquery.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/core/bootstrap.min.js"></script>
    <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chart JS -->
    <script src="./assets/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="./assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <script src="./assets/js/datatables.js"></script>

    <script>
    $(document).ready(function() {
        $('#support').DataTable({"order": []});
    });
    </script>
    <script>
    $(document).ready(function() {
        $('#lift').DataTable({"order": []});
    });
    </script>
</body>

</html>